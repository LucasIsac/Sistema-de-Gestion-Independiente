export default function Galeria() {
  return (
    <div>
      <h2>Página de Mensajes</h2>
      {/* Aquí irá el contenido de los mensajes */}
    </div>
  );
}
