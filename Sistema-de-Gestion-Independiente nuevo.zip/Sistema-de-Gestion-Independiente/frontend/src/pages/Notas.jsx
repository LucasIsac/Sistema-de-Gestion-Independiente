export default function Galeria() {
  return (
    <div>
      <h2>Página de Notas</h2>
      {/* Aquí irá el contenido para el Periodista */}
    </div>
  );
}
