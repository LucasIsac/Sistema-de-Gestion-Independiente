export default function Galeria() {
  return (
    <div>
      <h2>Página de Galería</h2>
      {/* Aquí irá el contenido para el fotógrafo */}
    </div>
  );
}
