WebApp de gestión de archivos diseñada para resolver las deficiencias actuales en el manejo de documentos del Diario El Independiente.  
